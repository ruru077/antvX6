import init from './dist/avoid-node.js'
import { readFileSync } from 'node:fs'
let instance
let loading
export const AvoidLib = {
  load(path = new URL('./dist/avoid-node.wasm', import.meta.url)) {
    return loading ??= init({ wasmBinary: readFileSync(path) }).then((value) => { instance = value }).catch((error) => { loading = undefined; throw error })
  },
  getInstance() {
    if (!instance) throw new Error('Avoid library is not initialized')
    return instance
  },
}
