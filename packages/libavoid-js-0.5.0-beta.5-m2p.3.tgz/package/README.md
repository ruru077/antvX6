# M2P libavoid — independent routing library

Local `libavoid-js` replacement for this application's routing API. Native code is
the same revision used by npm `libavoid-js@0.5.0-beta.5`: Aksem/adaptagrams
`0ab3467b4ed3523bb3e404a0dd7da7647d9eb13d` (tag `v1.0.5`). Native code and these
bindings are LGPL-2.1-or-later; see LICENSE. Source remains available from
https://github.com/Aksem/adaptagrams/tree/0ab3467b4ed3523bb3e404a0dd7da7647d9eb13d.

`bindings.cpp` exposes the application-used subset through Embind, including
`ConnRef.setFixedRoute`, `hasFixedRoute` and writable `Polygon`. It is not a
general drop-in replacement for every upstream libavoid-js API. `Polygon.at`
and `ConnRef.displayRoute` return owned copies: callers delete them. Router owns
its connectors, shapes and pins; temporary Point, Polygon and ConnEnd objects
are released by the caller. Each routing pass creates and disposes one Router.

Three minimal native patches are applied to temporary copies by `build.py`:

- `router.cpp`: crossing optimization must not clear/reroute fixed connections.
- `orthogonal.cpp`: nudging must freeze all fixed segments, including interior
  bends. Fixed segments remain constraints for other routes' spacing.
- `connector.cpp`: fixed orthogonal paths can cross another route inside a
  segment, away from visibility-graph vertices. Count these geometric
  intersections during crossing detection and path cost evaluation.

The real WASM tests check fixed bends after a crossing/spacing transaction and
show the active route changes when the fixed detour is present. Crossings are
still a soft constraint; fixed paths are not converted to solid obstacles.

## Rebuild

Requires Git, Python 3 and the project-local Emscripten SDK 3.1.36. No Docker or
global Emscripten installation is needed. From this library repository root, on Windows:

```powershell
git clone --branch 3.1.36 --depth 1 https://github.com/emscripten-core/emsdk.git .build/emsdk
& .build/emsdk/emsdk.bat install 3.1.36
& .build/emsdk/emsdk.bat activate 3.1.36
git clone --branch v1.0.5 --depth 1 https://github.com/Aksem/adaptagrams.git .build/adaptagrams
python build.py --sdk .build/emsdk --source .build/adaptagrams
npm run check
npm test
```

On Linux/macOS use `emsdk` instead of `emsdk.bat`. The build validates the native
revision and compiler version, maps source paths to deterministic names, and
generates separate web/Node loaders and WASM files. Commit all four dist files
and manifest.json together with binding changes. To independently rebuild and
compare without replacing checked-in files:

```powershell
python build.py --sdk .build/emsdk --source .build/adaptagrams --check
```

`npm run check` verifies binding/build inputs and checked-in artifact hashes.
`npm test` runs native WASM algorithm tests with Node's built-in test runner.
No dependency on Link, X6, Vite or an npm installation is required for these checks.

## Release to Link

Increment package.json version when publishing any change. Run:

```powershell
New-Item -ItemType Directory -Force releases
npm pack --pack-destination releases
```

The prepack hook checks artifacts and runs tests. Only dist, entry points, types,
package metadata, README and LICENSE enter the package; Python, C++ and tests remain
in this repository. Copy the resulting tgz into Link's packages directory and
update its dependency and lockfile. Link can then install and build without this
repository or the native compiler. Existing frontend integration/interaction tests
remain in Link because they exercise X6 events, history and routing scheduling.
