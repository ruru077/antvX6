import init from './dist/avoid-web.js'
let instance
let loading
export const AvoidLib = {
  load(path = new URL('./dist/avoid-web.wasm', import.meta.url).href) {
    return loading ??= init({ locateFile: () => path }).then((value) => { instance = value }).catch((error) => { loading = undefined; throw error })
  },
  getInstance() {
    if (!instance) throw new Error('Avoid library is not initialized')
    return instance
  },
}
