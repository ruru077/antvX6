export interface AvoidPoint { x: number; y: number; delete(): void }
export interface AvoidPolygon {
  size(): number
  at(index: number): AvoidPoint
  setPoint(index: number, point: AvoidPoint): void
  delete(): void
}
export interface AvoidConnection {
  setFixedRoute(path: AvoidPolygon): void
  hasFixedRoute(): boolean
  displayRoute(): AvoidPolygon
  setRoutingType(type: number): void
  setHateCrossings(value: boolean): void
}
export interface AvoidEnum { value: number }
export interface AvoidRouter {
  processTransaction(): boolean
  setRoutingParameter(parameter: AvoidEnum, value: number): void
  setRoutingOption(option: AvoidEnum, enabled: boolean): void
  delete(): void
}
export interface AvoidShape { readonly __shape?: never }
export interface AvoidPin { setExclusive(exclusive: boolean): void }
export interface AvoidEndpoint { delete(): void }
export interface Avoid {
  Point: new (x: number, y: number) => AvoidPoint
  Polygon: new (size: number) => AvoidPolygon
  Rectangle: new (topLeft: AvoidPoint, bottomRight: AvoidPoint) => AvoidPolygon
  Router: new (flags: number) => AvoidRouter
  ShapeRef: new (router: AvoidRouter, polygon: AvoidPolygon) => AvoidShape
  ShapeConnectionPin: new (shape: AvoidShape, id: number, x: number, y: number, proportional: boolean, offset: number, directions: number) => AvoidPin
  ConnEnd: {
    new (point: AvoidPoint): AvoidEndpoint
    new (shape: AvoidShape, pin: number): AvoidEndpoint
  }
  ConnRef: new (router: AvoidRouter, source: AvoidEndpoint, target: AvoidEndpoint) => AvoidConnection
  RouterFlag: { OrthogonalRouting: AvoidEnum }
  ConnType: { ConnType_Orthogonal: AvoidEnum }
  RoutingParameter: Record<'shapeBufferDistance' | 'idealNudgingDistance' | 'segmentPenalty' | 'anglePenalty' | 'crossingPenalty' | 'fixedSharedPathPenalty' | 'reverseDirectionPenalty' | 'portDirectionPenalty', AvoidEnum>
  RoutingOption: Record<'nudgeOrthogonalSegmentsConnectedToShapes' | 'nudgeSharedPathsWithCommonEndPoint' | 'performUnifyingNudgingPreprocessingStep' | 'nudgeOrthogonalTouchingColinearSegments', AvoidEnum>
}
export const AvoidLib: { load(path?: string | URL): Promise<void>; getInstance(): Avoid }
